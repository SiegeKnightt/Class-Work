USE Pizzeria;

SELECT * FROM basepizza;
SELECT * from customer;
SELECT * FROM delivery;
SELECT * FROM dinein;
SELECT * FROM discount;
SELECT * FROM orderdiscount;
SELECT * FROM orderpizza;
SELECT * FROM ordertopping;
SELECT * FROM pickup;
SELECT * FROM pizzadiscount;
SELECT * FROM pizzaorder;
SELECT * FROM topping;