Pledge:On my honor I have neither given nor received aid on this exam.
sde2.caml: Contains the code for the project.
sde2.log: Log of sample uses of each function in the project.
SDE2.pdf: Instrcutions for the assignment.